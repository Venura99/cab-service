export enum WellKnownLeaveStatus {
    PENDING = 1,
    APPROVED = 2,
    REJECTED = 3,
    CANCELLED = 4,
}
