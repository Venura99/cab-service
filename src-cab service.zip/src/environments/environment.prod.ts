export const environment = {
  production: true,
  apiURL: window["apiURL"] || "http://server-url",
};
