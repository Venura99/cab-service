window["apiURL"] = "http://server-Url:8090";
