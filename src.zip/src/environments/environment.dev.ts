export const environment = {
  production: false,
  apiURL: "http://localhost:8090",
};
