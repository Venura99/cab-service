export enum WellKnownTripStatus {
  PENDING = 1,
  CANCELED = 2,
  START = 3,
  FINISHED = 4,
}
