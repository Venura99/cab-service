export enum WellKnownUserRole {
  SUPERADMIN = 1,
  ADMIN = 2,
  DRIVER = 3,
  FINANCEOFFICER = 4,
  TRIPMANAGER = 5,
}
