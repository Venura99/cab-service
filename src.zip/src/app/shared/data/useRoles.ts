export const userRoles = [
  {
    name: "Super Admin",
    id: 1,
  },
  {
    name: "Admin",
    id: 2,
  },
  {
    name: "Driver",
    id: 3,
  },
  {
    name: "Finance Officer",
    id: 4,
  },
  {
    name: "Trip Manager",
    id: 5,
  },
];
