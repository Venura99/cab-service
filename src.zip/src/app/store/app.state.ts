export interface AppState {
  notifications: any[];
}
